

CREATE VIEW [Customer_Bought] AS
SELECT p.Price,p.Quantity FROM CustomerBoughtData p 



CREATE VIEW [Worker_Person] AS
SELECT p.Email,p.Pass FROM Person p INNER JOIN Worker w ON p.Id=w.Id



CREATE VIEW [Truck_View] AS
SELECT c.TId, t.Model, t.year, c.Price, c.Quantity FROM Companysolddata AS c INNER JOIN Truck AS t ON c.TId = t.Id



CREATE VIEW [Person view] AS
SELECT Id,Email,Pass
FROM Person


CREATE VIEW [ShopBoughtDataView] AS
SELECT t.CId, t.SId, t.TId,t.Quantity, t.Price ,t.Date FROM ShopBoughtData t



//STORE PROCEDURE
1.
CREATE PROCEDURE CBD
@Name Varchar(100)
AS
BEGIN
SELECT csd.TId,csd.Price,csd.Quantity FROM Customer c JOIN Person p ON c.Id=p.Id JOIN CustomerBoughtData csd ON csd.CId=c.Id WHERE c.Name=@Name;
END

//To Execute run this 
CBD 'ABC'

2.

CREATE PROCEDURE spgetrr
@Id Varchar(100)
AS
BEGIN
SELECT c.[Return Rate] FROM Company c WHERE c.Id=Id;
END

//To Execute run this 
spgetrr 1

3. 

CREATE PROCEDURE spshoptruck
@ShopName Varchar(100)
AS
BEGIN
SELECT sb.TId,sb.Price FROM Shop s JOIN ShopBoughtData sb ON s.SID=sb.SId WHERE s.ShopName=@ShopName;
END

//To Execute run this 
spshoptruck 'ABC'


4.
CREATE PROCEDURE spcompanytruck
@CompanyName Varchar(100)
AS
BEGIN
SELECT sb.TId,sb.Price FROM Company s JOIN Companysolddata sb ON s.Id=sb.CId WHERE s.Name=@CompanyName;
END

//To Execute run this 
spcompanytruck 'unilever'