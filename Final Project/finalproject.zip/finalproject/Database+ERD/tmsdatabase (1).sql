USE tms2;
GO
/****** Object:  Table [dbo].[Person]  ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Person](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Pass] [varchar](100) NOT NULL,
	[Role] [varchar](100) NOT NULL,
	[FirstName] [varchar](100) NOT NULL,
	[LastName] [varchar](100) NULL,
	[Contact] [varchar](20) NULL,
	[Email] [varchar](30) NOT NULL,
	[Gender] [int] NULL,
 CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Customer]   ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Customer](
	[Id] [int] NOT NULL,
	[Name] [varchar](20) NOT NULL,
 CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Id of person is foreignkey for customer ******/
ALTER TABLE [dbo].[Customer]  WITH CHECK ADD  CONSTRAINT [FK_Customer_Person] FOREIGN KEY([Id])
REFERENCES [dbo].[Person] ([Id])
GO
ALTER TABLE [dbo].[Customer] CHECK CONSTRAINT [FK_Customer_Person]
GO
/**shopowner**/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ShopOwner](
	[Id] [int] NOT NULL,
	[Name] [varchar](20) NOT NULL,
 CONSTRAINT [PK_ShopOwner] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Id of person is foreignkey for shopowner ******/
ALTER TABLE [dbo].[ShopOwner]  WITH CHECK ADD  CONSTRAINT [FK_ShopOwner_Person] FOREIGN KEY([Id])
REFERENCES [dbo].[Person] ([Id])
GO
ALTER TABLE [dbo].[ShopOwner] CHECK CONSTRAINT [FK_ShopOwner_Person]
GO

/******  Table [dbo].[Lookup] value from lookup ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Lookup](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Value] [varchar](100) NOT NULL,
	[Category] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Lookup] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[Lookup] ON
INSERT [dbo].[Lookup] ([Id], [Value], [Category]) VALUES (1, N'Male', N'GENDER')
INSERT [dbo].[Lookup] ([Id], [Value], [Category]) VALUES (2, N'Female', N'GENDER')
INSERT [dbo].[Lookup] ([Id], [Value], [Category]) VALUES (3, N'Active', N'STATUS')
INSERT [dbo].[Lookup] ([Id], [Value], [Category]) VALUES (4, N'InActive', N'STATUS')
SET IDENTITY_INSERT [dbo].[Lookup] OFF
/****** Object:  ForeignKey [FK_Person_Lookup]    ******/
ALTER TABLE [dbo].[Person]  WITH CHECK ADD  CONSTRAINT [FK_Person_Lookup] FOREIGN KEY([Gender])
REFERENCES [dbo].[Lookup] ([Id])
GO
ALTER TABLE [dbo].[Person] CHECK CONSTRAINT [FK_Person_Lookup]
GO

/****Object: [Company***/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Company](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Email] [varchar](30) NOT NULL,
	[Pass] [varchar](100) NOT NULL,
	[Name] [varchar](50) NOT NULL,
	[Return Rate] [int] NOT NULL,
 CONSTRAINT [PK_Company] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  ForeignKey [FK_ShopReturnData_Company]***
ALTER TABLE [dbo].[ShopReturnData]  WITH CHECK ADD  CONSTRAINT [FK_ShopReturnData_Company] FOREIGN KEY([CId])
REFERENCES [dbo].[Company] ([Id])
GO
ALTER TABLE [dbo].[ShopReturnData] CHECK CONSTRAINT [FK_ShopReturnData_Company]
GO*/
/*companyowner*/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CompanyOwner](
	[Id] [int] NOT NULL,
	[Name] [varchar](20) NOT NULL,
 CONSTRAINT [PK_CompanyOwner] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Id of person is foreignkey for companyowner ******/
ALTER TABLE [dbo].[CompanyOwner]  WITH CHECK ADD  CONSTRAINT [FK_CompanyOwner_Person] FOREIGN KEY([Id])
REFERENCES [dbo].[Person] ([Id])
GO
ALTER TABLE [dbo].[CompanyOwner] CHECK CONSTRAINT [FK_CompanyOwner_Person]
GO
/****Object :[ShowRoom]***/
SET ANSI_NULLS ON
GO 
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Shop](
	[SID] [int] IDENTITY(1,1) NOT NULL,
	[Email] [varchar](30) NOT NULL,
	[Pass] [varchar](100) NOT NULL,
	[ShopName] [varchar](50) NOT NULL,
	[Return Rate] [int] NULL,
 CONSTRAINT [PK_ShowRoom] PRIMARY KEY CLUSTERED
(
	[SID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO

/***Object: [Truck]***/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Truck](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Model] [varchar](50) NOT NULL,
	[year] [int] NULL,
	[Price] [int] NULL,
	[Quantity] [int] NOT NULL,
 CONSTRAINT [PK_Truck] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX =OFF,STATISTICS_NORECOMPUTE =OFF, IGNORE_DUP_KEY =OFF, ALLOW_ROW_LOCKS =ON, ALLOW_PAGE_LOCKS =ON) ON [PRIMARY]
)ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/**[Worker]**/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Worker](
	[Id] [int] NOT NULL,
	[Image] [varchar] NULL,
 CONSTRAINT [PK_Worker] PRIMARY KEY CLUSTERED
(
	[Id] ASC
)WITH (PAD_INDEX =OFF,STATISTICS_NORECOMPUTE =OFF, IGNORE_DUP_KEY =OFF, ALLOW_ROW_LOCKS =ON, ALLOW_PAGE_LOCKS =ON) ON [PRIMARY]
)ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  ForeignKey [FK_Worker_Person] ******/
ALTER TABLE [dbo].[Worker]  WITH CHECK ADD  CONSTRAINT [FK_Worker_Person] FOREIGN KEY([Id])
REFERENCES [dbo].[Person] ([Id])
GO
ALTER TABLE [dbo].[Worker] CHECK CONSTRAINT [FK_Worker_Person]
GO
/**CustomerBoughtData*/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CustomerBoughtData](
	[CId] [int] NOT NULL,
	[SId] [int] NOT NULL,
	[TId] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[Price] [int] NOT NULL,
	[Date] [Date] NOT NULL,
 CONSTRAINT [PK_CustomerBoughtData] PRIMARY KEY CLUSTERED
(
	[CId] ASC,
	[SId] ASC,
	[TId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  ForeignKey [FK_CustomerBoughtData_Customers]    Script Date: 01/22/2018 09:46:30 ******/
ALTER TABLE [dbo].[CustomerBoughtData]  WITH NOCHECK ADD  CONSTRAINT [FK_CustomerBoughtData_Customer] FOREIGN KEY([CId])
REFERENCES [dbo].[Customer] ([Id])
GO
ALTER TABLE [dbo].[CustomerBoughtData] CHECK CONSTRAINT [FK_CustomerBoughtData_Customer]
GO
/****** Object:  ForeignKey [FK_CustomerBoughtData_Shop]    ******/
ALTER TABLE [dbo].[CustomerBoughtData]  WITH NOCHECK ADD  CONSTRAINT [FK_CustomerBoughtData_Shop] FOREIGN KEY([SID])
REFERENCES [dbo].[Shop] ([SID])
GO
ALTER TABLE [dbo].[CustomerBoughtData] CHECK CONSTRAINT [FK_CustomerBoughtData_Shop]
GO
/****** Object:  ForeignKey [FK_CompanyBoughtData_Truck]     ******/
ALTER TABLE [dbo].[CustomerBoughtData]  WITH NOCHECK ADD  CONSTRAINT [FK_CustomerBoughtData_Truck] FOREIGN KEY([TId])
REFERENCES [dbo].[Truck] ([Id])
GO
ALTER TABLE [dbo].[CustomerBoughtData] CHECK CONSTRAINT [FK_CustomerBoughtData_Truck]
GO
/****** Object:  Table [dbo].[AppliedWorker]     ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AppliedWorker](
	[Id] [Int] NOT NULL,
	[SId] [Int] NOT NULL,
	[Status] [Int] NOT NULL,
 CONSTRAINT [PK_AppliedWorker] PRIMARY KEY CLUSTERED 
(
	[Id] ASC,
	[SId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object id from worker******/
ALTER TABLE [dbo].[AppliedWorker]  WITH CHECK ADD  CONSTRAINT [FK_Worker] FOREIGN KEY([Id])
REFERENCES [dbo].[Worker] ([Id])
GO
ALTER TABLE [dbo].[AppliedWorker] CHECK CONSTRAINT [FK_Worker]
GO
/****** Object sid from shop******/
ALTER TABLE [dbo].[AppliedWorker]  WITH CHECK ADD  CONSTRAINT [FK_Shop_AppliedWorker] FOREIGN KEY([SId])
REFERENCES [dbo].[Shop] ([SId])
GO
ALTER TABLE [dbo].[AppliedWorker] CHECK CONSTRAINT [FK_Shop_AppliedWorker]
GO
/****** Object:  ForeignKey [FK_AppliedWorker_Lookup]    ******/
ALTER TABLE [dbo].[AppliedWorker]  WITH CHECK ADD  CONSTRAINT [FK_AppliedWorker_Lookup] FOREIGN KEY([Status])
REFERENCES [dbo].[Lookup] ([Id])
GO
ALTER TABLE [dbo].[AppliedWorker] CHECK CONSTRAINT [FK_AppliedWorker_Lookup]
GO
/**SHOP MONTHLY PROFIT**/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ShopMonthlyData](
	[SId] [Int] NOT NULL,
	[Profit] [Int] NOT NULL,
	[Monthly] [datetime] NOT NULL,
 CONSTRAINT [PK_ShopMonthlyData] PRIMARY KEY CLUSTERED 
(
	[SId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

/***shop sid**/
ALTER TABLE [dbo].[ShopMonthlyData]  WITH CHECK ADD  CONSTRAINT [FK_ShopMonthlyData_Shop] FOREIGN KEY([SId])
REFERENCES [dbo].[Shop] ([SId])
GO
ALTER TABLE [dbo].[ShopMonthlyData] CHECK CONSTRAINT [FK_ShopMonthlyData_Shop]
GO
/**Company MONTHLY PROFIT**/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CompanyMonthlyData](
	[CId] [Int] NOT NULL,
	[Profit] [Int] NOT NULL,
	[Monthly] [datetime] NOT NULL,
 CONSTRAINT [PK_CompanyMonthlyData] PRIMARY KEY CLUSTERED 
(
	[CId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  ForeignKey [FK_CompanyMonthlyData_ShowRoom]    ******/
ALTER TABLE [dbo].[CompanyMonthlyData]  WITH CHECK ADD  CONSTRAINT [FK_CompanyMonthlyData_Company] FOREIGN KEY([CId])
REFERENCES [dbo].[Company] ([Id])
GO
ALTER TABLE [dbo].[CompanyMonthlyData] CHECK CONSTRAINT [FK_CompanyMonthlyData_Company]
GO

/*customer return data*/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CustomerReturnData](
	[RId] [Int] IDENTITY(1,1) NOT NULL,
	[ShopId] [Int] NOT NULL,
	[TId] [Int] NOT NULL,
	[Rqty] [Int] NULL,
	[Rprice] [Int] NOT NULL,
 CONSTRAINT [PK_CustomerReturnData] PRIMARY KEY CLUSTERED 
(
	[RId] ASC,
	[ShopId] ASC,
	[TId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  ForeignKey [FK_ShopReturnData_Company]     ******/
ALTER TABLE [dbo].[CustomerReturnData]  WITH NOCHECK ADD  CONSTRAINT [FK_CustomerReturnData_Shop] FOREIGN KEY([ShopId])
REFERENCES [dbo].[Shop] ([SId])
GO
ALTER TABLE [dbo].[CustomerReturnData] CHECK CONSTRAINT [FK_CustomerReturnData_Shop]
GO
/****** Object:  ForeignKey [FK_CustomerReturnData_Truck] *****/
ALTER TABLE [dbo].[CustomerReturnData]  WITH NOCHECK ADD  CONSTRAINT [FK_CustomerReturnData_Truck] FOREIGN KEY([TId])
REFERENCES [dbo].[Truck] ([Id])
GO
ALTER TABLE [dbo].[CustomerReturnData] CHECK CONSTRAINT [FK_CustomerReturnData_Truck]
GO
/*ShopReturnData*/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ShopGivebackCompany](
	[RId] [Int] IDENTITY(1,1) NOT NULL,
	[CId] [Int] NOT NULL,
	[TId] [Int] NOT NULL,
	[Rqty] [Int] NULL,
	[Rprice] [Int] NOT NULL,
 CONSTRAINT [PK_ShopGivebackCompany] PRIMARY KEY CLUSTERED 
(
	[RId] ASC,
	[CId] ASC,
	[TId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  ForeignKey [FK_ShopReturnData_Company]     ******/
ALTER TABLE [dbo].[ShopGivebackCompany]  WITH NOCHECK ADD  CONSTRAINT [FK_ShopGivebackCompany_Company] FOREIGN KEY([CId])
REFERENCES [dbo].[Company] ([Id])
GO
ALTER TABLE [dbo].[ShopGivebackCompany] CHECK CONSTRAINT [FK_ShopGivebackCompany_Company]
GO
/****** Object:  ForeignKey [FK_ShopReturnData_Truck] *****/
ALTER TABLE [dbo].[ShopGivebackCompany]  WITH NOCHECK ADD  CONSTRAINT [FK_ShopGivebackCompany_Truck] FOREIGN KEY([TId])
REFERENCES [dbo].[Truck] ([Id])
GO
ALTER TABLE [dbo].[ShopGivebackCompany] CHECK CONSTRAINT [FK_ShopGivebackCompany_Truck]
GO

/**companysolddata*/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Companysolddata](
	[CId] [int] NOT NULL,
	[TId] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[Price] [int] NOT NULL,
	[Date] [Date] NOT NULL,
 CONSTRAINT [PK_Companysolddata] PRIMARY KEY CLUSTERED
(
	[CId] ASC,
	[TId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  ForeignKey [FK_CompanySoldData_Company]    ******/
ALTER TABLE [dbo].[Companysolddata]  WITH CHECK ADD  CONSTRAINT [FK_Companysolddata_Company] FOREIGN KEY([CId])
REFERENCES [dbo].[Company] ([Id])
GO
ALTER TABLE [dbo].[Companysolddata] CHECK CONSTRAINT [FK_Companysolddata_Company]
GO
/****** Object:  ForeignKey [FK_CompanySoldData_Truck]     ******/
ALTER TABLE [dbo].[Companysolddata]  WITH NOCHECK ADD  CONSTRAINT [FK_Companysolddata_Truck] FOREIGN KEY([TId])
REFERENCES [dbo].[Truck] ([Id])
GO
ALTER TABLE [dbo].[Companysolddata] CHECK CONSTRAINT [FK_Companysolddata_Truck]
GO
/**shopsolddata*/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Shopsolddata](
	[SId] [int] NOT NULL,
	[TId] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[Price] [int] NOT NULL,
	[Date] [Date] NOT NULL,
 CONSTRAINT [PK_Shopsolddata] PRIMARY KEY CLUSTERED
(
	[SId] ASC,
	[TId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  ForeignKey [FK_CompanySoldData_Company]    ******/
ALTER TABLE [dbo].[Shopsolddata]  WITH CHECK ADD  CONSTRAINT [FK_Shopsolddata_Shop] FOREIGN KEY([SId])
REFERENCES [dbo].[Shop] ([SId])
GO
ALTER TABLE [dbo].[Shopsolddata] CHECK CONSTRAINT [FK_Shopsolddata_Shop]
GO
/****** Object:  ForeignKey [FK_ShopSoldData_Truck]     ******/
ALTER TABLE [dbo].[Shopsolddata]  WITH NOCHECK ADD  CONSTRAINT [FK_Shopsolddata_Truck] FOREIGN KEY([TId])
REFERENCES [dbo].[Truck] ([Id])
GO
ALTER TABLE [dbo].[Shopsolddata] CHECK CONSTRAINT [FK_Shopsolddata_Truck]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*Shopboughtdata*/
CREATE TABLE [dbo].[ShopBoughtData](
	[CId] [int] NOT NULL,
	[SId] [int] NOT NULL,
	[TId] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[Price] [int] NOT NULL,
	[Date] [Date] NOT NULL,
 CONSTRAINT [PK_ShopBoughtData] PRIMARY KEY CLUSTERED
(
	[CId] ASC,
	[SId] ASC,
	[TId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  ForeignKey [FK_ShopBoughtData_Company]    Script Date: 01/22/2018 09:46:30 ******/
ALTER TABLE [dbo].[ShopBoughtData]  WITH NOCHECK ADD  CONSTRAINT [FK_ShopBoughtData_Company] FOREIGN KEY([CId])
REFERENCES [dbo].[Company] ([Id])
GO
ALTER TABLE [dbo].[ShopBoughtData] CHECK CONSTRAINT [FK_ShopBoughtData_Company]
GO
/****** Object:  ForeignKey [FK_ShopBoughtData_Shop]    ******/
ALTER TABLE [dbo].[ShopBoughtData]  WITH NOCHECK ADD  CONSTRAINT [FK_ShopBoughtData_Shop] FOREIGN KEY([SID])
REFERENCES [dbo].[Shop] ([SID])
GO
ALTER TABLE [dbo].[ShopBoughtData] CHECK CONSTRAINT [FK_ShopBoughtData_Shop]
GO
/****** Object:  ForeignKey [FK_ShopBoughtData_Truck]     ******/
ALTER TABLE [dbo].[ShopBoughtData]  WITH NOCHECK ADD  CONSTRAINT [FK_ShopBoughtData_Truck] FOREIGN KEY([TId])
REFERENCES [dbo].[Truck] ([Id])
GO
ALTER TABLE [dbo].[ShopBoughtData] CHECK CONSTRAINT [FK_ShopBoughtData_Truck]
GO

