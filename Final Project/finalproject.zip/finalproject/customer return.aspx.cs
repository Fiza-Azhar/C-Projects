﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using TruckManagementSystem.BL;
using System.Web.UI.WebControls;

namespace TruckManagementSystem
{
    public partial class customer_return : System.Web.UI.Page
    {
        string compid, trid;
        string sc = ConfigurationManager.ConnectionStrings["con"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int qq = 0;
            int q = int.Parse(tqty.Text.Trim());
            int p = int.Parse(tprice.Text.Trim());
            if (q != 0)
            {
                qq = p / q;
            }
            int quan = int.Parse(qt.Text.Trim());
            int f = quan * qq;
            price.Text = f.ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sc);
            int cidd = int.Parse(cid.Text.Trim());
            DateTime d = DateTime.Today;
            int tidd = int.Parse(truckid.Text.Trim());
            int p = int.Parse(price.Text.Trim());
            int quantity = int.Parse(qt.Text.Trim());
            int tquantity = int.Parse(tqty.Text.Trim());
            int tpr = int.Parse(tprice.Text.Trim());
            int Customerid = int.Parse(sid.Text.Trim());
            Response.Write("<script>alert('Values taken from textboxes');</script>");
            CustomerReturnBL b = new CustomerReturnBL(cidd, tidd, p, quantity, tquantity, Customerid, tpr);
            Response.Write("<script>alert('" + b.Quantity2 + "');</script>");
            string check = CustomerReturnBL.Adddata(b, sc);
            Response.Write("<script>alert('" + check + "');</script>");
            if (check == "done")
            {
                Response.Redirect("customer view.aspx");
            }
        }
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = GridView1.SelectedRow;
            compid = gr.Cells[2].Text;
            sid.Text = gr.Cells[1].Text;
            trid = gr.Cells[3].Text;
            tprice.Text = gr.Cells[5].Text.ToString();
            tqty.Text = gr.Cells[4].Text;
            cid.Text = compid;
            truckid.Text = trid;

        }
    }
}