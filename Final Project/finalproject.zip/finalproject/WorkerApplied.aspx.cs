﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using TruckManagementSystem.DL;
using TruckManagementSystem.BL;


namespace TruckManagementSystem
{
    public partial class WorkerApplied : System.Web.UI.Page
    {
        string wid;
        protected void Page_Load(object sender, EventArgs e)
        {
            wid = Request.QueryString["Parameter"];
            Response.Write("<script>alert('Welcome " + wid + " ');</script>");
        }
         
        protected void Button1_Click(object sender, EventArgs e)
        {
            string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            string sName = TextBox1.Text;
            Response.Write("<script>alert('" + sName + "');</script>");

            int sId = WorkerBL.getShopId(strcon, sName);
            Response.Write("<script>alert('" + sId + "');</script>");
            string ans = "done";
            SqlConnection conn = new SqlConnection(strcon);
            conn.Open();
            SqlCommand cmd = new SqlCommand("Insert into AppliedWorker (Id,SId, Status) values (@Id, @SId, @Status)", conn);
            cmd.Parameters.AddWithValue("@Id", wid);
            cmd.Parameters.AddWithValue("@SId", sId);
            cmd.Parameters.AddWithValue("@Status", "Active");
            conn.Close();
            //string result = WorkerBL.addAppliedWorker(sId, int.Parse(wid), strcon);
           // Response.Write("<script>alert('" + result + "');</script>");

        }
    }
}