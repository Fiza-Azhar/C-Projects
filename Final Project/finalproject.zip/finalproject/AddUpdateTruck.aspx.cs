﻿using System;
using System.Web.UI;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using TruckManagementSystem.BL;
using TruckManagementSystem.DL;


namespace TruckManagementSystem
{
    public partial class AddUpdateTruck : System.Web.UI.Page
    {
        string cid;
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            cid = Request.QueryString["Parameter"];
            Response.Write("<script>alert('Welcome " + cid + " Company ');</script>");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(strcon);
            SqlCommand cmd2 = new SqlCommand("Select Id from Truck Where Model = @model AND year=@year", conn);
            cmd2.CommandTimeout = 0;
            cmd2.Parameters.AddWithValue("@model", TextBox1.Text.Trim());
            cmd2.Parameters.AddWithValue("@year", TextBox2.Text.Trim());
            int tid = (int)cmd2.ExecuteScalar();
            try
            {
                if (!(CompanySoldDataDL.checkCompanyDataExists(strcon, int.Parse(cid), TextBox1.Text,int.Parse(TextBox2.Text))))
                {
                    SqlConnection con = new SqlConnection(strcon);
                    string s = "alert(\"Please wait!\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                    string model = TextBox1.Text.Trim();
                    int year = int.Parse(TextBox2.Text.Trim());
                    int price = int.Parse(TextBox3.Text.Trim());
                    int quantity = int.Parse(TextBox4.Text.Trim());
                    TruckBL truck = new TruckBL(model, year, price, quantity);
                    string check = "Not updated";
                    Response.Write("<script>alert('" + check + "');</script>");
                    check = TruckBL.AddTruck(truck, strcon);
                    Response.Write("<script>alert('" + check + "');</script>");
                    Response.Write("<script>alert('we are back ');</script>");
                    if (check == "done")
                    {
                        s = "alert(\"done\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                        Response.Write("<script>alert('Sign Up Successful. Go to User Login to Login');</script>");
                    }
                }
                else
                {
                    Response.Write("<script>alert('Company already exists');</script>");

                }

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('Going in');</script>");

            if (CompanySoldDataDL.checkCompanyDataExists(strcon, int.Parse(cid), TextBox1.Text, int.Parse(TextBox2.Text)))
            {
                if (TruckDL.checkTruckDataExists(strcon, int.Parse(cid), TextBox1.Text, int.Parse(TextBox2.Text)))
                {
                    Response.Write("<script>alert('I'm in');</script>");

                    string result = CompanySoldData.updateCompanyTruck(strcon, TextBox1.Text, int.Parse(TextBox2.Text), int.Parse(TextBox3.Text), int.Parse(TextBox4.Text), int.Parse(cid));
                    string r = TruckBL.updateTruck(strcon, TextBox1.Text, int.Parse(TextBox2.Text), int.Parse(TextBox3.Text), int.Parse(TextBox4.Text));
                    Response.Write("<script>alert('Bout to check');</script>");

                    if (r == "done" && result == "done")
                    {
                        Response.Write("<script>alert('Values Updated');</script>");
                    }
                    else
                    {
                        Response.Write("<script>alert('Not updated');</script>");

                    }
                }
                else
                {
                    Response.Write("<script>alert('Truck does not exist');</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Truck in company does not exist');</script>");
            }
            GridView1.DataBind();
        }
        protected void Button4_Click(object sender, EventArgs e)
        {

        }
    }
}