﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using TruckManagementSystem.DL;
using TruckManagementSystem.BL;

namespace TruckManagementSystem
{
    public partial class WorkerLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            {
                string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
                if (!(WorkerDL.WorkerLogIn(TextBox1.Text.Trim(), TextBox2.Text.Trim()) == "failed"))
                {
                    //string check = CustomerDL.CustomerLogIn(TextBox1.Text.Trim(), TextBox2.Text.Trim());
                    //Response.Write("<script>alert('Welcome " + check + " Worker ');</script>");
                    SqlConnection conn = new SqlConnection(strcon);
                    conn.Open();
                    SqlCommand cmd2 = new SqlCommand("Select Id from Person Where Email = @email AND Pass=@pass", conn);
                    cmd2.CommandTimeout = 0;
                    cmd2.Parameters.AddWithValue("@email", TextBox1.Text.Trim());
                    cmd2.Parameters.AddWithValue("@pass", TextBox2.Text.Trim());
                    int cid = (int)cmd2.ExecuteScalar();
                    Response.Redirect("WorkerApplied.aspx?Parameter=" + cid);
                }
                else
                {
                    Response.Write("<script>alert('Invalid credentials');</script>");
                }
            }
        }
    }
}