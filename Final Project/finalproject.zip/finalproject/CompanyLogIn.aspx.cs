﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using TruckManagementSystem.DL;
using TruckManagementSystem.BL;

namespace TruckManagementSystem
{
    public partial class CompanyLogIn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            if(!(CompanyDL.CompanyLogIn( TextBox1.Text.Trim(), TextBox2.Text.Trim()) == "failed"))
            {
                string check = CompanyDL.CompanyLogIn(TextBox1.Text.Trim(), TextBox2.Text.Trim());
                Response.Write("<script>alert('Welcome " + check + " Company ');</script>");
                SqlConnection conn = new SqlConnection(strcon);
                conn.Open();
                SqlCommand cmd2 = new SqlCommand("Select Id from Company Where Email = @email AND Pass=@pass", conn);
                cmd2.CommandTimeout = 0;
                cmd2.Parameters.AddWithValue("@email", TextBox1.Text.Trim());
                cmd2.Parameters.AddWithValue("@pass", TextBox2.Text.Trim());
                int cid = (int)cmd2.ExecuteScalar();
                Response.Redirect("CompanyAddTrucks.aspx?Parameter=" + cid);
            }
            else
            {
                Response.Write("<script>alert('Invalid credentials');</script>");
            }
        }
        
    }
}