﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using TruckManagementSystem.DL;
using TruckManagementSystem.BL;

namespace TruckManagementSystem
{
    public partial class CompanySignUp : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
                //Response.Write("<script>alert('Testing now');</script>");
                try
                {
                    if (!CompanyDL.checkCompanyExists(strcon, TextBox2.Text.Trim(), TextBox1.Text.Trim()))
                    {
                        SqlConnection con = new SqlConnection(strcon);
                        /* if (con.State == ConnectionState.Closed)
                         {
                             con.Open();
                         }*/
                        //Response.Write("<script>alert('hello again');</script>");
                        string s = "alert(\"Please wait!\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                        string CName = TextBox1.Text.Trim();
                        string email = TextBox2.Text.Trim();
                        string password = TextBox3.Text.Trim();
                        int ReturnRate = int.Parse(TextBox4.Text.Trim());
                        //Response.Write("<script>alert('taken values');</script>");
                        /* SqlCommand cmd = new SqlCommand("insert into company(Email, Pass, Name, [Return Rate]) values('Sahib@gmail.com', '7282', 'STrucks', 7)", con);
                         cmd.ExecuteNonQuery();*/
                        //Response.Write("<script>alert('adding values');</script>");

                        /*SqlCommand cmd2 = new SqlCommand("insert into company (Email,Pass,Name,[Return Rate]) values (@Email, @Pass, @Name, @Return_Rate)", con);
                        cmd2.Prepare();
                        cmd2.Parameters.AddWithValue("@Email", email);
                        cmd2.Parameters.AddWithValue("@Pass", password);
                        cmd2.Parameters.AddWithValue("@Name", CName);
                        cmd2.Parameters.AddWithValue("@Return_Rate", ReturnRate);*/
                        CompanyBL Comp = new CompanyBL(email, password, CName, ReturnRate);

                        string check = "Not updated";
                        Response.Write("<script>alert('" + check + "');</script>");
                        check = CompanyBL.AddCompany(Comp, strcon);
                        Response.Write("<script>alert('" + check + "');</script>");
                        Response.Write("<script>alert('we are back ');</script>");
                        //int v = cmd2.ExecuteNonQuery();
                        //con.Close();
                        //Response.Write("<script>alert('adding values 222');</script>");
                        // Response.Write("<script>alert('executed ');</script>");
                        if (check == "done")
                        {
                            s = "alert(\"done\");";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                            Response.Write("<script>alert('Sign Up Successful. Go to User Login to Login');</script>");
                        }
                    }
                    else
                    {
                        Response.Write("<script>alert('Company already exists');</script>");

                    }

                }
                catch (Exception ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            
        }

           
    }
}

       
    
