﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using TruckManagementSystem.DL;
using TruckManagementSystem.BL;

namespace TruckManagementSystem
{
    public partial class customer_login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            string email = TextBox1.Text.Trim();
            string password = TextBox2.Text.Trim();

            if (CustomerDL.CustomerLogIn(strcon, email, password))
            {
                Response.Write("<script>alert('Welcome Customer');</script>");

                int customerId = CustomerDL.GetPersonIdForLogin(strcon,email, password);
                if (customerId != -1)
                {
                    Response.Redirect($"customer view.aspx?Parameter={customerId}");
                }
                else
                {
                    Response.Write("<script>alert('Error: Could not retrieve customer ID.');</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('Invalid credentials');</script>");
            }








            /*string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            if (!(CustomerDL.CustomerLogIn(TextBox1.Text.Trim(), TextBox2.Text.Trim()) == "failed"))
            {
                string check = CustomerDL.CustomerLogIn(TextBox1.Text.Trim(), TextBox2.Text.Trim());
                Response.Write("<script>alert('Welcome " + check + " Customer ');</script>");
                SqlConnection conn = new SqlConnection(strcon);
                conn.Open();
                SqlCommand cmd2 = new SqlCommand("Select Id from Person Where Email = @email AND Pass=@pass", conn);
                cmd2.CommandTimeout = 0;
                cmd2.Parameters.AddWithValue("@email", TextBox1.Text.Trim());
                cmd2.Parameters.AddWithValue("@pass", TextBox2.Text.Trim());
                int cid = (int)cmd2.ExecuteScalar();
                Response.Redirect("customer view.aspx?Parameter=" + cid);
            }
            else
            {
                Response.Write("<script>alert('Invalid credentials');</script>");
            }*/
        }
    }
}


