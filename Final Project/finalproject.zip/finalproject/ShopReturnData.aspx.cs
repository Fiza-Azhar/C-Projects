﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using TruckManagementSystem.BL;
using System.Web.UI.WebControls;

namespace TruckManagementSystem
{
    public partial class ShopReturnData : System.Web.UI.Page
    {
        string compid, trid;
        string shid;
        string sc = ConfigurationManager.ConnectionStrings["con"].ConnectionString;

        protected void Button3_Click(object sender, EventArgs e)
        {
            int qq=0;
            int q= int.Parse(tqty.Text.Trim());
            int p = int.Parse(tprice.Text.Trim());
            if (q != 0)
            {
                 qq = p / q;
            }
            int quan= int.Parse(qt.Text.Trim());
            int f = quan * qq;
            price.Text = f.ToString();

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            shid = Request.QueryString["Parameter"];
            Parameter p = SqlDataSource2.SelectParameters["shid"];
            SqlDataSource2.SelectParameters.Remove(p);
            SqlDataSource2.SelectParameters.Add("shid", shid);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            
                SqlConnection con = new SqlConnection(sc);
                int cidd = int.Parse(cid.Text.Trim());
                DateTime d = DateTime.Today;
                int tidd = int.Parse(truckid.Text.Trim());
                int p = int.Parse(price.Text.Trim());
                int quantity = int.Parse(qt.Text.Trim());
                int tquantity = int.Parse(tqty.Text.Trim());
                int tpr = int.Parse(tprice.Text.Trim());
                int shopid = int.Parse(sid.Text.Trim());
                Response.Write("<script>alert('Values taken from textboxes');</script>");
                ShopReturnTruck b = new ShopReturnTruck(cidd, tidd, p, quantity,tquantity,shopid,tpr);
                Response.Write("<script>alert('"+b.Quantity2+"');</script>");
                string check = ShopReturnTruck.Adddata(b, sc);
                Response.Write("<script>alert('" + check + "');</script>");
                if (check == "done")
                {
                Response.Redirect("Shopmenutab.aspx");
                //Response.Write("<script>alert('Successfull');</script>");
                }


         
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = GridView1.SelectedRow;
            compid = gr.Cells[1].Text;
            sid.Text = gr.Cells[2].Text;
            trid = gr.Cells[3].Text;
            tprice.Text = gr.Cells[5].Text.ToString();
            tqty.Text = gr.Cells[4].Text;
            cid.Text = compid;
            truckid.Text = trid;
            
        }
        private int value(ref int p,ref int q)
        {
            int a = p / q;
            Response.Write("<script>alert('" + a + "');</script>");
            return a;
        }


    }
}