﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using CrystalDecisions.CrystalReports.Engine;
using TruckManagementSystem.BL;
using System.Web.UI.WebControls;
using CrystalDecisions.Shared;

namespace TruckManagementSystem
{
    public partial class Shopmenutab : System.Web.UI.Page
    {
        private string sid;
        string sc = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            sid = Request.QueryString["Parameter"];
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("ShopAdTruck.aspx?Parameter=" + sid);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("ShopReturnData.aspx?Parameter=" + sid);
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("AllCompaniesReport.aspx?Parameter=" + sid);
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomerReport.aspx?Parameter=" + sid);
        }
        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("AllTrucks.aspx?Parameter=" + sid);
        }
        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("PersonView.aspx?Parameter=" + sid);
        }
        protected void Button7_Click(object sender, EventArgs e)
        {
            //Response.Redirect("SpecificTrucks.aspx?Parameter=" + sid);
            SqlConnection con = new SqlConnection(sc);
            con.Open();
            SqlCommand cmd = new SqlCommand("spshoptruck '" + Shopidd.Text + "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            ReportDocument crp = new ReportDocument();
            crp.Load(Server.MapPath("CrystalReport7.rpt"));
            crp.SetDataSource(ds.Tables["Table"]);
            crp.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, false, "STruck");
        }
        
    }
}