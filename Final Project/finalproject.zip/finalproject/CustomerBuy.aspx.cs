﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckManagementSystem
{
    public partial class CustomerBuy : System.Web.UI.Page
    {
        private string cid = "", tid = "", price = "", qty = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            cid = Request.QueryString["Parameter"];
        }
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = GridView1.SelectedRow;
            tid = gr.Cells[1].Text;
            price = gr.Cells[4].Text;
            qty = gr.Cells[5].Text;
            Response.Write("<script>alert('" + price + "');</script>");
            Response.Redirect("CustomerBuyTruck.aspx?Parameter=" + cid + "&tid=" + tid + "&price=" + price + "&qty=" + qty);
        }
    }
}