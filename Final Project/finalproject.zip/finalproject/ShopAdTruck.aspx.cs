﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckManagementSystem
{

    public partial class ShopAdTruck : System.Web.UI.Page
    {
        private string sid="",tid="",price="",qty="";
        
        protected void Page_Load(object sender, EventArgs e)
        {
            sid = Request.QueryString["Parameter"];
          
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = GridView1.SelectedRow;
            tid = gr.Cells[1].Text;
            price = gr.Cells[4].Text;
            qty = gr.Cells[5].Text;
            Response.Write("<script>alert('" + price + "');</script>");
            Response.Redirect("Shopbuytruck.aspx?Parameter=" + sid + "&tid=" + tid + "&price=" + price + "&qty=" + qty); 
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            /*  int row = ((GridViewRow)(sender as Control).NamingContainer).RowIndex;
              int id = Convert.ToInt32(GridView1.Rows[row].Cells[0].Text);
              TextBox1.Text = id.ToString();*/
           /* Response.Write("<script>alert('" + sid + "');</script>");
            tid = GridView1.SelectedRow.Cells[0].Text;          
            Response.Redirect("Shopbuytruck.aspx?Parameter=" + sid + "&tid=" + tid);*/
        }
    }
}