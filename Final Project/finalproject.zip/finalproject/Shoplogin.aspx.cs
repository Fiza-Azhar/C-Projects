﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TruckManagementSystem.DL;

namespace TruckManagementSystem
{
    public partial class Shoplogin : System.Web.UI.Page
    {
        string sc = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void Button1_TextChanged(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (ShopLoginDL.Shoplogin(sc, TextBox2.Text.Trim(), TextBox3.Text.Trim()))
                {
                    Response.Write("<script>alert('Successfully Login');</script>");
                    SqlConnection conn = new SqlConnection(sc);
                    conn.Open();
                    SqlCommand cmd2 = new SqlCommand("Select SID from Shop Where Email = @email AND Pass=@pass", conn);
                    Response.Write("<script>alert('hy')</script>");
                    cmd2.Parameters.AddWithValue("@email", TextBox2.Text);
                    cmd2.Parameters.AddWithValue("@pass", TextBox3.Text);
                    Response.Write("<script>alert('hy')</script>");
                    int sid = (int)cmd2.ExecuteScalar();
                    Response.Redirect("Shopmenutab.aspx?Parameter=" + sid);
                }
                else
                {
                    Response.Write("<script>alert('Invalid, Login Fail');</script>");

                }
            }
            catch (Exception exp)
            {

            }
        }
    }
}