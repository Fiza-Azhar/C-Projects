﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TruckManagementSystem.BL;
using TruckManagementSystem.DL;

namespace TruckManagementSystem
{
    public partial class ShopSignUp : System.Web.UI.Page
    {
        string sc = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_TextChanged(object sender, EventArgs e)
        {
           // Response.Write("<script>alert('Sign Up Successful. Go to User Login to Login');</script>");
        }
     /*   protected void Button1_Click(object sender, EventArgs e)
        {
             Response.Write("<script>alert('Sign Up Successful. Go to User Login to Login');</script>");
            Response.Redirect("ShopLogin.aspx");
        }*/

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (ShopSignupDL.checkuser(sc, TextBox2.Text.Trim()))
            {

                Response.Write("<script>alert('Someone is already logged in with with that email Try another one');</script>");

            }
            else
            {

                signup();
            }   
        }

       
        public void signup()
        {
            try
            {
                string Name = TextBox1.Text.Trim();
                string email = TextBox2.Text.Trim();
                string password = TextBox3.Text.Trim();
                int ReturnRate = int.Parse(TextBox4.Text.Trim());
                Response.Write("<script>alert('taken values from textboxes');</script>");
                ShopsignupBL s = new ShopsignupBL(email, password, Name, ReturnRate);
                string ss=ShopsignupBL.ShopSignup(s, sc);
                if(ss=="Successfull")
                {
                    Response.Write("<script>alert('Successfully SignUp');</script>");
                    Response.Redirect("ShopLogin.aspx");
                }
                else
                {
                    Response.Write("<script>alert('" + ss + "');</script>");
                }
                /* SqlCommand cm = new SqlCommand("insert into Shop(Email, Pass, ShopName, [Return Rate]) values('"+email+"', '"+password+"', '"+Name+"', '"+ReturnRate+"')", conn);
                 cm.ExecuteNonQuery();
                 //  SqlCommand cm = new SqlCommand("insert into Shop(Email, Pass, ShopName, [Return Rate]) values(@Email, @Pass, @ShopName, @[Return Rate])", conn);
                 // SqlCommand cmd = new SqlCommand("insert into Shop(Email, Pass, ShopName, [Return Rate]) values (@Email, @Pass, @ShopName, @[Return Rate])", conn);
                 /* cm.Prepare();
                  cm.Parameters.AddWithValue("@Email", email);
                  cm.Parameters.AddWithValue("@Pass", password);
                  cm.Parameters.AddWithValue("@ShopName", Name);
                  cm.Parameters.AddWithValue("@[Return Rate]", ReturnRate);
                  cm.ExecuteNonQuery();*/
                /* Response.Write("<script>alert('adding values');</script>");
                 conn.Close();
                 Response.Write("<script>alert('Sign Up Successful');</script>");*/
              

            }
            catch (Exception exp)
            {
                Response.Write("<script>alert('" + exp.Message + "');</script>");
                
            }
        }
    }
}