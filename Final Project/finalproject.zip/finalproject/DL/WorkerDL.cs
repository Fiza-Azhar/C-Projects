﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace TruckManagementSystem.DL
{
    public class WorkerDL
    {
        public static bool checkWorkerExists(string strcon, string email, string fname)
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("SELECT * from Person where Email='" + email + "'AND FirstName='" + fname + "';", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public static string WorkerLogIn(string email, string password)
        {
            string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
            string a = " ";
            SqlConnection conn = new SqlConnection(strcon);
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();

            }
            SqlCommand cmd = new SqlCommand("select * from Person where Email='" + email + "' AND Pass='" + password + "'", conn);
            SqlDataReader dr = cmd.ExecuteReader();
            cmd.CommandTimeout = 0;
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    a = dr.GetValue(2).ToString();
                    return a;
                }
            }
            else
            {
                a = "failed";
                return a;
            }
            return a;
        }
    }
}