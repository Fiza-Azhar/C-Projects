﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Web;
using System.Data;

namespace TruckManagementSystem.DL
{
    public class ShopSignupDL
    {
       public static bool checkuser(string sc,string email)
       {

            try
            {
                SqlConnection s = new SqlConnection(sc);
                if (s.State == ConnectionState.Closed)
                {
                    s.Open();
                }
                SqlCommand cmd = new SqlCommand("SELECT * from Shop where Email='" + email + "';", s);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }   
            catch(Exception exp)
            {
                return false;
            }

        }

    }
}