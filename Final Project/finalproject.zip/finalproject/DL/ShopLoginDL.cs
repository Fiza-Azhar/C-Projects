﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace TruckManagementSystem.DL
{
    public class ShopLoginDL
    {
        public static bool Shoplogin(string sc, string email, string password)
        {
    
            try
            {
                SqlConnection conn = new SqlConnection(sc);
                conn.Open();
                SqlCommand cm = new SqlCommand("select * from Shop where Email='" + email + "' AND Pass='" + password + "'", conn);
                SqlDataReader dr = cm.ExecuteReader(); //execute query  \\dr isdata  reader//
                if (dr.HasRows)
                {
                    return true;
                }
                else
                {
                    return false;
                }
               
            }
            catch (Exception exp)
            {
                return false;
            }
        }


    }
}
