﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace TruckManagementSystem.DL
{
    public class CustomerDL
    {
        public CustomerDL()
        {

        }
        public static bool checkCustomerExistsById(string strcon, int id)
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand cmd = new SqlCommand("SELECT * from Customer where Id=" + id, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public static int GetPersonIdForLogin(string strcon, string email, string password)
        {
            int personId = 0;
            try
            {
                SqlConnection conn = new SqlConnection(strcon);
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                SqlCommand cmd = new SqlCommand("select Id from Person where Email='" + email + "' AND Pass='" + password + "'", conn);
                SqlDataReader dr = cmd.ExecuteReader();
                cmd.CommandTimeout = 0;
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        personId = Convert.ToInt32(dr.GetValue(0));
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                return 0;
            }
            return personId;
        }
        public static int GetPersonIdForSignup(string strcon, string Fname, string Email)
        {
            int personId = 0;
            try
            {
                SqlConnection conn = new SqlConnection(strcon);
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                SqlCommand cmd = new SqlCommand("select Id from Person where Email='" + Email + "' AND FirstName='" + Fname + "'", conn);
                SqlDataReader dr = cmd.ExecuteReader();
                cmd.CommandTimeout = 0;
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        personId = Convert.ToInt32(dr.GetValue(0));
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                return 0;
            }
            return personId;
        }
        public static bool CustomerLogIn(string strcon, string email, string password)
        {
            int personId = GetPersonIdForLogin(strcon, email, password);
            if (personId == 0)
            {
                return false;
            }
            else
            {
                bool existsInCustomer = checkCustomerExistsById(strcon, personId);
                if (existsInCustomer)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

    }

}















