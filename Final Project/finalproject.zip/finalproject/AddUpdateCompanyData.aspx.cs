﻿using System;
using System.Web.UI;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using TruckManagementSystem.BL;
using TruckManagementSystem.DL;
using System.Web.UI.WebControls;
using System.Transactions;

namespace TruckManagementSystem
{
    public partial class AddUpdateCompanyData : System.Web.UI.Page
    {
        string cid;
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            cid = Request.QueryString["Parameter"];
            Response.Write("<script>alert('Welcome " + cid + " Company ');</script>");
            //SqlDataSource2.SelectParameters.Add("@cid", cid);
            Parameter p = SqlDataSource2.SelectParameters["cid"];
            SqlDataSource2.SelectParameters.Remove(p);
            SqlDataSource2.SelectParameters.Add("cid", cid);
            /* SqlParameter parameter1 = new SqlParameter("@cid", SqlDbType.BigInt);
             parameter1.Value = cid;
             SqlDataSource2.SelectParameters.Add(parameter1);*/
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            /* SqlConnection conn = new SqlConnection(strcon);
             conn.Open();*/
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            /*SqlTransaction transaction1;
            transaction1 = con.BeginTransaction();*/
            try
            {
                using (TransactionScope txn = new TransactionScope())
                {

                    string s = "alert(\"Please wait!\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                    string model = TextBox1.Text.Trim();
                    int year = int.Parse(TextBox2.Text.Trim());
                    int price = int.Parse(TextBox3.Text.Trim());
                    int quantity = int.Parse(TextBox4.Text.Trim());
                    TruckBL truck = new TruckBL(model, year, price, quantity);
                    string check = "Not updated";
                    Response.Write("<script>alert('" + check + "');</script>");
                    check = TruckBL.AddTruck(truck, strcon);
                    Response.Write("<script>alert('" + check + "');</script>");
                    check = "Now Company";
                    Response.Write("<script>alert('" + check + "');</script>");
                    check = CompanySoldData.AddCompanyTruck(truck, strcon, int.Parse(cid));
                    //transaction1.Commit();
                    Response.Write("<script>alert('we are back ');</script>");
                    Response.Write("<script>alert('" + check + "');</script>");
                    if (check == "done")
                    {
                        s = "alert(\"done\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                        Response.Write("<script>alert('Truck added successfully');</script>");
                    }
                    con.Close();
                    txn.Complete();
                }
            }
            catch (Exception ex)
            {
                //transaction1.Rollback();
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            Response.Redirect(Page.Request.RawUrl, true);
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            /*SqlTransaction t2;
            t2 = con.BeginTransaction();*/
            try
            {
                using (TransactionScope ts = new TransactionScope())
                {
                    if (CompanySoldDataDL.checkCompanyDataExists(strcon, int.Parse(cid), TextBox1.Text, int.Parse(TextBox2.Text)))
                    {
                        if (TruckDL.checkTruckDataExists(strcon, int.Parse(cid), TextBox1.Text, int.Parse(TextBox2.Text)))
                        {

                            string result = CompanySoldData.updateCompanyTruck(strcon, TextBox1.Text, int.Parse(TextBox2.Text), int.Parse(TextBox3.Text), int.Parse(TextBox4.Text), int.Parse(cid));
                            string r = TruckBL.updateTruck(strcon, TextBox1.Text, int.Parse(TextBox2.Text), int.Parse(TextBox3.Text), int.Parse(TextBox4.Text));
                            //t2.Commit();
                            if (r == "done" && result == "done")
                            {
                                Response.Write("<script>alert('Values Updated');</script>");
                            }
                            else
                            {
                                Response.Write("<script>alert('Not updated');</script>");

                            }
                        }
                        else
                        {
                            Response.Write("<script>alert('Truck does not exist');</script>");
                        }
                    }
                    else
                    {
                        Response.Write("<script>alert('Truck in company does not exist');</script>");
                    }
                    GridView1.DataBind();
                    ts.Complete();
                }
            }
            catch (Exception ex)
            {
                //t2.Rollback();
            }


        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            /*if (CompanySoldDataDL.checkCompanyDataExists(strcon, int.Parse(cid), TextBox1.Text.Trim(), int.Parse(TextBox2.Text.Trim())))
            {
                string result = CompanySoldData.deleteCompanyTruck(strcon, int.Parse(TextBox2.Text.Trim()), TextBox1.Text.Trim());
                string r = TruckBL.deleteTruck(strcon, int.Parse(TextBox2.Text.Trim()), TextBox1.Text.Trim());
                if(result == "done" && r == "done")
                {
                    Response.Write("<script>alert('Truck is deleted  ');</script>");
                }
                else
                {
                    Response.Write("<script>alert('There was a problem ');</script>");
                    Response.Write("<script>alert('" + result + "');</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('This truck does not exists');</script>");
            }
            GridView1.DataBind();
        }*/
        }
    }
}