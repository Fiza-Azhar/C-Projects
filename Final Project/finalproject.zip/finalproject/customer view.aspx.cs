﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckManagementSystem
{
    public partial class customer_view : System.Web.UI.Page
    {
        private string cid;
        protected void Page_Load(object sender, EventArgs e)
        {
            cid = Request.QueryString["Parameter"];
            Response.Write("<script>alert('Welcome " + cid + " Customer ');</script>");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("customer return.aspx?Parameter=" + cid);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomerBuy.aspx?Parameter=" + cid);
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("CustomerReport.aspx?Parameter=" + cid);
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("AllCustomersReport.aspx?Parameter=" + cid);
        }
        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("AllShopsReport.aspx?Parameter=" + cid);
        }
        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("AllCompaniesReport.aspx?Parameter=" + cid);
        }
        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Redirect("AllTrucks.aspx?Parameter=" + cid);
        }
    }
}