﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using TruckManagementSystem.DL;
using TruckManagementSystem.BL;

namespace TruckManagementSystem
{
    public partial class Worker_Signup : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        string check = "Not updated";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (!WorkerDL.checkWorkerExists(strcon, TextBox4.Text.Trim(), TextBox1.Text.Trim()))
                {
                    SqlConnection con = new SqlConnection(strcon);
                    string s = "alert(\"Please wait!\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                    string FName = TextBox1.Text.Trim();
                    string LName = TextBox2.Text.Trim();
                    string email = TextBox4.Text.Trim();
                    string password = TextBox5.Text.Trim();
                    int contact = int.Parse(TextBox3.Text.Trim());
                    int gender = 0;
                    string role = "Worker";
                    if (RadioMale.Checked)
                    {
                        gender = 1;
                    }
                    else
                    {
                        gender = 2;
                    }
                    Response.Write("<script>alert('Values taken from textboxes');</script>");
                    Response.Write("<script>alert('Values taken from textboxes');</script>");
                    WorkerBL Comp = new WorkerBL(password, role, FName, LName, contact, email, gender);
                    check = WorkerBL.WorkerSignup(Comp, strcon);
                    Response.Write("<script>alert('" + check + "');</script>");

                    // check = CustomerBL.AddCustomer(Comp, strcon);
                    Response.Write("<script>alert('we are back ');</script>");
                    if (check == "done")
                    {
                        s = "alert(\"done\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                        Response.Write("<script>alert('Sign Up Successful. Go to User Login to Login');</script>");
                    }
                }
                else
                {
                    Response.Write("<script>alert('Worker already exists');</script>");

                }

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            }

         }
    }
    
