﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using CrystalDecisions.CrystalReports.Engine;
using TruckManagementSystem.BL;
using System.Web.UI.WebControls;
using CrystalDecisions.Shared;

namespace TruckManagementSystem
{
    public partial class AllShopsReport : System.Web.UI.Page
    {
        string sc = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sc);
            // con.Open();
            SqlCommand cmd = new SqlCommand("Select SID,Email,ShopName,[Return Rate] from Shop", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            ReportDocument crp = new ReportDocument();
            crp.Load(Server.MapPath("CrystalReport3.rpt"));
            crp.SetDataSource(ds.Tables["Table"]);
            CrystalReportViewer1.ReportSource = crp;
            crp.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, false, "Shops");
        }
    }
}