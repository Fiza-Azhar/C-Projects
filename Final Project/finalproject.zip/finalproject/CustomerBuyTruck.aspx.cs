﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TruckManagementSystem.BL;

namespace TruckManagementSystem
{
    public partial class CustomerBuyTruck : System.Web.UI.Page
    {
        string sc = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        private string id, tid, p, qty;
        protected void Page_Load(object sender, EventArgs e)
        {
            id = Request.QueryString["Parameter"];
            tid = Request.QueryString["tid"];
            p = Request.QueryString["price"];
            qty = Request.QueryString["qty"];
            sid.Text = id.ToString();
            truckid.Text = tid.ToString();
            // pr.Text = p.ToString();
            SqlConnection conn = new SqlConnection(sc);
            conn.Open();
            SqlCommand cmd2 = new SqlCommand("SELECT c.SId FROM Shopsolddata AS c INNER JOIN Truck AS t ON c.TId = t.Id where c.TId=@Tid", conn);
            cmd2.Parameters.AddWithValue("@Tid", truckid.Text.Trim());
            int compid = (int)cmd2.ExecuteScalar();
            cid.Text = compid.ToString();
        }

        protected void qtyy_TextChanged(object sender, EventArgs e)
        {

        }


        protected void Button3_Click(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Button2_Click1(object sender, EventArgs e)
        {

        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            int a = int.Parse(quan.Text);
            int totalPrice = int.Parse(p);
            int totalQty = int.Parse(qty);
            int pp = totalPrice / totalQty;
            pr.Text = (a * pp).ToString();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(sc);
                string s = "alert(\"Please wait!\");";
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                int cidd = int.Parse(cid.Text.Trim());
                int sidd = int.Parse(sid.Text.Trim());
                DateTime d = DateTime.Today;
                int tidd = int.Parse(truckid.Text.Trim());
                int price = int.Parse(pr.Text.Trim());
                int quantity = int.Parse(quan.Text.Trim());
                CustomerBoughtBL b = new CustomerBoughtBL(sidd, tidd, cidd, price, quantity, d);
                string check = CustomerBoughtBL.Adddata(b, sc);
                Response.Write("<script>alert('" + check + "');</script>");
                if (check == "done")
                {
                    s = "alert(\"done\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                    Response.Write("<script>alert('Successfully Added');</script>");
                }


            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }


    }
}