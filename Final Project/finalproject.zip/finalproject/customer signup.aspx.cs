﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using TruckManagementSystem.DL;
using TruckManagementSystem.BL;

namespace TruckManagementSystem
{
   
    public partial class customer_signup : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        string check = "Not updated";
        

        protected void Button3_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                    string s = "alert(\"Please wait!\");";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                    string FName = TextBox1.Text.Trim();
                    string LName = TextBox2.Text.Trim();
                    string email = TextBox4.Text.Trim();
                    string password = TextBox5.Text.Trim();
                    int contact = int.Parse(TextBox3.Text.Trim());
                    int gender = 0;
                    string role = "Customer";
                    if (RadioMale.Checked)
                    {
                    gender = 1;
                    }
                    else
                    {
                    gender = 2;
                    }
                    Response.Write("<script>alert('Values taken from textboxes');</script>");
                int pId = CustomerDL.GetPersonIdForSignup(strcon,FName, email);
                bool customerExists = CustomerDL.checkCustomerExistsById(strcon, pId);
                if (customerExists)
                {
                     s = "alert(\"A customer with the same Id and Name already exists.\");";
                }
                CustomerBL Comp = new CustomerBL(password,role,FName,LName,contact,email,gender);
                    check=CustomerBL.AddCustomer(Comp, strcon);
                    Response.Write("<script>alert('" + check + "');</script>");

                   // check = CustomerBL.AddCustomer(Comp, strcon);
                    Response.Write("<script>alert('we are back ');</script>");
                    if (check == "done")
                    {
                        s = "alert(\"done\");";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", s, true);
                        Response.Write("<script>alert('Sign Up Successful. Go to User Login to Login');</script>");
                    }

}
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
}
    }
}








