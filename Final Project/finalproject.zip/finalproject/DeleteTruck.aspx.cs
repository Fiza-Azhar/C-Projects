﻿using System;
using System.Web.UI;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using TruckManagementSystem.BL;
using TruckManagementSystem.DL;
using System.Web.UI.WebControls;


namespace TruckManagementSystem
{
    public partial class DeleteTruck : System.Web.UI.Page
    {
        string cid;
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            cid = Request.QueryString["Parameter"];
            Response.Write("<script>alert('Welcome " + cid + " Company ');</script>");
            Parameter p = SqlDataSource1.SelectParameters["cid"];
            SqlDataSource1.SelectParameters.Remove(p);
            SqlDataSource1.SelectParameters.Add("cid", cid);
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlTransaction t3;
            t3 = con.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                if (CompanySoldDataDL.checkCompanyDataExists(strcon, int.Parse(cid), TextBox1.Text.Trim(), int.Parse(TextBox2.Text.Trim())))
                {
                    string result = CompanySoldData.deleteCompanyTruck(strcon, int.Parse(TextBox2.Text.Trim()), TextBox1.Text.Trim());
                    string r = TruckBL.deleteTruck(strcon, int.Parse(TextBox2.Text.Trim()), TextBox1.Text.Trim());
                    if (result == "done" && r == "done")
                    {
                        Response.Write("<script>alert('Truck is deleted  ');</script>");
                    }
                    else
                    {
                        Response.Write("<script>alert('There was a problem ');</script>");
                        Response.Write("<script>alert('" + result + "');</script>");
                    }
                }
                else
                {
                    Response.Write("<script>alert('This truck does not exists');</script>");
                }
                GridView1.DataBind();
            }
            catch(Exception ex)
            {
                t3.Rollback();
            }
        }
    }
}