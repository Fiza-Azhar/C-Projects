﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using TruckManagementSystem.BL;
using TruckManagementSystem.DL;

namespace TruckManagementSystem.BL
{
    public class CompanySoldData
    {
        private int CId, TId, Quantity, Price;
        private DateTime Date;
        public CompanySoldData(int CId, int TId, int price, int quantity, DateTime date)
        {
            this.CId = CId;
            this.TId = TId;
            this.Price = price;
            this.Quantity = quantity;
            this.Date = date;
        }

        public CompanySoldData CompanySoldData1
        {
            get => default;
            set
            {
            }
        }

        public ShopBoughtdataBL ShopBoughtdataBL
        {
            get => default;
            set
            {
            }
        }

        public static string AddCompanyTruck(TruckBL t, string con, int Cid)
        {
            string ans = "done";
            try
            {
                SqlConnection conn = new SqlConnection(con);
                conn.Open();
                SqlCommand cmd2 = new SqlCommand("Select Id from Truck Where Model = @model AND Year = @year", conn);
                //cmd2.Transaction = trans;
                cmd2.Parameters.AddWithValue("@model", t.Model);
                cmd2.Parameters.AddWithValue("@year", t.Year);
                int Tid = (int)cmd2.ExecuteScalar();
                conn.Close();
                //return Tid.ToString();
                SqlConnection conn2 = new SqlConnection(con);
                conn2.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Companysolddata(CId, TId, Quantity, Price, Date) values (@CId, @TId, @Quantity, @Price, @Date)", conn2);
                //cmd.Transaction = trans;
                cmd.Parameters.AddWithValue("@CId", Cid);
                cmd.Parameters.AddWithValue("@Tid", Tid);
                cmd.Parameters.AddWithValue("@Quantity", t.Quantity);
                cmd.Parameters.AddWithValue("@Price", t.Price);
                DateTime today = DateTime.Now;
                cmd.Parameters.AddWithValue("@Date", today.ToString("MM/dd/yyyy"));
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                ans = e.Message;
                return ans;
            }
            return ans;
        }
        public static string deleteCompanyTruck(string strcon, int year, string model)
        {
            string result = "not updated";
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                int id = getTruckId(strcon, model, year);
                SqlCommand cmd = new SqlCommand("DELETE from Companysolddata WHERE TId='" + id + "'", con);

                cmd.ExecuteNonQuery();
                con.Close();
                result = "done";
                return result;
            }
            catch (Exception ex)
            {
                result = ex.ToString();
                return result;
            }
        }

        public static string updateCompanyTruck(string strcon, string model, int year, int price, int quan, int cid)
        {
            string result = "not updated";
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
            int Tid = getTruckId(strcon, model, year);
                SqlCommand cmd = new SqlCommand("UPDATE Companysolddata SET Price=@price, Quantity = @quan, Date = @Date WHERE TId= @TId AND CId = @cid;", con);

                cmd.Parameters.AddWithValue("@price", price);
                cmd.Parameters.AddWithValue("@quan", quan);
                cmd.Parameters.AddWithValue("@TId", Tid);
                cmd.Parameters.AddWithValue("@cid", cid);
                DateTime today = DateTime.Today;
                cmd.Parameters.AddWithValue("@Date", today);
                cmd.ExecuteNonQuery();
                con.Close();

                result = "done";
                return result;
            }
            catch (Exception ex)
            {
                result = ex.ToString();
                return result;
            }
        }
        public static int getTruckId(string con, string model , int year)
        {
            SqlConnection conn = new SqlConnection(con);
            conn.Open();
            SqlCommand cmd2 = new SqlCommand("Select Id from Truck Where Model = @model AND Year = @year", conn);
            cmd2.Parameters.AddWithValue("@model", model);
            cmd2.Parameters.AddWithValue("@year", year);
            int Tid = (int)cmd2.ExecuteScalar();
            conn.Close();
            return Tid;
        }

    }
}