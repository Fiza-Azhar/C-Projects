﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace TruckManagementSystem.BL
{
    public class CustomerReturnBL
    {
        private int sid, tid, quantity1, quantity2, price, customerId, price2;
        public CustomerReturnBL(int sid, int tid, int price, int quantity1, int quantity2, int Customerid, int price2)
        {
            this.Sid = sid;
            this.Tid = tid;
            this.Price = price;
            this.Price2 = price2;
            this.Quantity1 = quantity1;
            this.Quantity2 = quantity2;
            this.CustomerId = Customerid;
        }
        //getter and setter methods provides encapsulation
        public int Sid { get => sid; set => sid = value; }
        public int Tid { get => tid; set => tid = value; }
        public int Quantity1 { get => quantity1; set => quantity1 = value; }
        public int Quantity2 { get => quantity2; set => quantity2 = value; }
        public int Price { get => price; set => price = value; }
        public int CustomerId { get => customerId; set => customerId = value; }
        public int Price2 { get => price2; set => price2 = value; }

        public static string Adddata(CustomerReturnBL t, string con)
        {
            string ans;

            ans = "done";
            SqlConnection conn2 = new SqlConnection(con);
            conn2.Open();
            if (t.Quantity1 < t.Quantity2)
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO CustomerReturnData(ShopId,TId, Rqty, Rprice) values (@SId,@TId, @Rqty, @Rprice)", conn2);
                cmd.Parameters.AddWithValue("@SId", t.Sid);
                cmd.Parameters.AddWithValue("@TId", t.Tid);
                cmd.Parameters.AddWithValue("@Rqty", t.Quantity1);
                cmd.Parameters.AddWithValue("@Rprice", t.Price);
                SqlCommand cmd2 = new SqlCommand("Update CustomerBoughtData SET Price=@price, Quantity = @quantity, Date = @Date WHERE TId= @TId AND CId = @CustomerId AND SId=@SId;", conn2);
                cmd2.Parameters.AddWithValue("@SId", t.Sid);
                cmd2.Parameters.AddWithValue("@TId", t.Tid);
                cmd2.Parameters.AddWithValue("@CustomerId", t.CustomerId);
                int q = t.Quantity2 - t.Quantity1;
                cmd2.Parameters.AddWithValue("@quantity", q);
                int pr = (t.Price2 / t.Quantity2);
                int returnrate = getreturnrate(conn2, t.customerId);
                int pr2 = (t.Price2 - (t.Quantity1 * pr) - returnrate);
                cmd2.Parameters.AddWithValue("@price", pr2);
                cmd2.Parameters.AddWithValue("@Date", DateTime.Today);
                cmd.ExecuteNonQuery();
                cmd2.ExecuteNonQuery();
            }
            else if (t.Quantity1 == t.Quantity2)
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO CustomerReturnData(ShopId,TId, Rqty, Rprice) values (@SId,@TId, @Rqty, @Rprice)", conn2);
                cmd.Parameters.AddWithValue("@SId", t.Sid);
                cmd.Parameters.AddWithValue("@TId", t.Tid);
                cmd.Parameters.AddWithValue("@Rqty", t.Quantity1);
                cmd.Parameters.AddWithValue("@Rprice", t.Price);
                cmd.ExecuteNonQuery();
                SqlCommand cmd2 = new SqlCommand("Delete from CustomerBoughtData where TId=@TId AND SId=@SId", conn2);
                cmd2.Parameters.AddWithValue("@SId", t.Sid);
                cmd2.Parameters.AddWithValue("@TId", t.Tid);
              /*  cmd2.Parameters.AddWithValue("@Rqty", t.Quantity1);
                cmd2.Parameters.AddWithValue("@Rprice", t.Price);*/
                cmd2.ExecuteNonQuery();
            }
            else
            {
                ans = "Quantity should be less than or rqual to original amount";
                return ans;
            }

            return ans;
        }

        public static int getreturnrate(SqlConnection conn, int id)//spGetRate
        {
            SqlCommand cmd2 = new SqlCommand("spGetRate id", conn);
            //  cmd2.Parameters.AddWithValue("@Id", id);
            int shopid = (int)cmd2.ExecuteScalar();
            /*SqlCommand cmd2 = new SqlCommand("Select [Return Rate] from Shop Where SID = @Id ", conn);
            cmd2.Parameters.AddWithValue("@Id", id);
            int shopid = (int)cmd2.ExecuteScalar();
            return shopid;*/
            return shopid;
        }
    }
}