﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace TruckManagementSystem.BL
{
    public class CompanyBL
    {
        private string name;
        private string email;
        private string password;
        private int rate;
        public CompanyBL(string email, string password, string name, int rate)
        {
            this.name = name;
            this.password = password;
            this.email = email;
            this.rate = rate;
        }

        public CompanySoldData CompanySoldData
        {
            get => default;
            set
            {
            }
        }

        public CompanySoldData CompanySoldData1
        {
            get => default;
            set
            {
            }
        }

        public TruckBL TruckBL
        {
            get => default;
            set
            {
            }
        }

        public static string AddCompany(CompanyBL c, string con)
        {
            string ans = "done";
            try
            {
                SqlConnection conn = new SqlConnection(con);
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Company(Email, Pass, Name, [Return Rate]) values (@Email, @Pass, @Name, @Return_Rate)", conn);
                cmd.Parameters.AddWithValue("@Email", c.email);
                cmd.Parameters.AddWithValue("@Pass", c.password);
                cmd.Parameters.AddWithValue("@Name", c.name);
                cmd.Parameters.AddWithValue("@Return_Rate", c.rate);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch(Exception e)
            {
                ans = e.Message;
                return ans;
            }
            return ans;
        }

    }
}