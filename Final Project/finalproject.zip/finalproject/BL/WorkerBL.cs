﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace TruckManagementSystem.BL
{
    public class WorkerBL
    {
        private string FirstName;
        private string LastName;
        private int Gender;
        private string Email;
        private string Password;
        private int Contact;
        private string Role;

        public WorkerBL(string password, string role, string firstname, string lastname, int contact, string email, int gender)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.Gender = gender;
            this.Password = password;
            this.Email = email;
            this.Contact = contact;
            this.Role = role;
        }
        public static string WorkerSignup(WorkerBL s, string sc)
        {
            string ans;
            try
            {
                ans = "done";
                SqlConnection conn = new SqlConnection(sc);
                conn.Open();
                SqlCommand cm = new SqlCommand("Insert into Person(Pass, Role, FirstName, LastName, Contact, Email, Gender) values('" + s.Password + "', '" + s.Role + "', '" + s.FirstName + "', '" + s.LastName + "','" + s.Contact + "','" + s.Email + "','" + s.Gender + "')", conn);
                cm.ExecuteNonQuery();
                int id = getPersonId(sc, s.Password, s.Email);
                string img = "1";
                SqlCommand cmd = new SqlCommand("Insert into Worker (Id, Image) values (@Id, @Image)", conn);
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Parameters.AddWithValue("@Image", img);
                conn.Close();
            }
            catch (Exception exp)
            {
                ans = exp.Message;
                return ans;
            }
            return ans;
        }
        public static string addAppliedWorker(int SId, int WId, string strcon)
        {
            string ans;
            /*try
            {*/
                ans = "done";
                SqlConnection conn = new SqlConnection(strcon);
                conn.Open();
                SqlCommand cmd = new SqlCommand("Insert into AppliedWorker (Id,SId, Status) values (@Id, @SId, @Status)", conn);
                cmd.Parameters.AddWithValue("@Id", WId);
                cmd.Parameters.AddWithValue("@SId", SId);
                cmd.Parameters.AddWithValue("@Status", "Active");
                conn.Close();
            //}
            /*catch (Exception exp)
            {
                ans = exp.Message;
                return ans;
            }*/
            return ans;
        }
        public static int getPersonId(string con, string Pass, string email)
        {
            SqlConnection conn = new SqlConnection(con);
            conn.Open();
            SqlCommand cmd2 = new SqlCommand("Select Id from Person Where Email = @email AND Pass = @Pass", conn);
            cmd2.Parameters.AddWithValue("@email", email);
            cmd2.Parameters.AddWithValue("@Pass", Pass);
            int Tid = (int)cmd2.ExecuteScalar();
            conn.Close();
            return Tid;
        }
        public static int getShopId(string con, string name)
        {
            SqlConnection conn = new SqlConnection(con);
            conn.Open();
            SqlCommand cmd2 = new SqlCommand("Select SId from Shop Where ShopName = @Name", conn);
            cmd2.Parameters.AddWithValue("@Name", name);
            int Tid = (int)cmd2.ExecuteScalar();
            conn.Close();
            return Tid;
        }
    }
}