﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace TruckManagementSystem.BL
{
    public class TruckBL
    {
        private string model;
        private int year;
        private int price;
        private int quantity;
        public TruckBL(string model, int year, int price, int quantity)
        {
            this.model = model;
            this.year = year;
            this.price = price;
            this.quantity = quantity;
        }

        public int Price { get => price; set => price = value; }
        public int Quantity { get => quantity; set => quantity = value; }
        public string Model { get => model; set => model = value; }
        public int Year { get => year; set => year = value; }

        public static string AddTruck(TruckBL t, string con)
        {
            string ans = "done";
            try
            {
                SqlConnection conn = new SqlConnection(con);
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Truck(Model, year, Price, Quantity) values (@Model, @year, @Price, @Quantity)", conn);
                //cmd.Transaction = trans;
                cmd.Parameters.AddWithValue("@Model", t.model);
                cmd.Parameters.AddWithValue("@year", t.year);
                cmd.Parameters.AddWithValue("@Price", t.price );
                cmd.Parameters.AddWithValue("@Quantity", t.quantity);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                ans = e.Message;
                return ans;
            }
            return ans;
        }
        public static string deleteTruck(string strcon, int year, string model)
        {
            string result = "not updated";
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                SqlCommand cmd = new SqlCommand("DELETE from Truck WHERE model='" + model + "'AND year ='" + year + "'", con);
                //cmd.Transaction = t3;
                cmd.ExecuteNonQuery();
                con.Close();
                result = "done";
                return result;

            }
            catch (Exception ex)
            {
                result = ex.ToString();
                return result;
            }
        }
        public static string updateTruck(string strcon, string model, int year, int price, int quan)
        {
            string result = "not updated";
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                int t = CompanySoldData.getTruckId(strcon, model, year);
                SqlCommand cmd = new SqlCommand("UPDATE Truck SET Price=@price, Quantity = @quan WHERE Model= @model AND year = @year AND Id = @t;", con);

                cmd.Parameters.AddWithValue("@price", price);
                cmd.Parameters.AddWithValue("@quan", quan);
                cmd.Parameters.AddWithValue("@model", model);
                cmd.Parameters.AddWithValue("@year", year);
                cmd.Parameters.AddWithValue("@t", t);



                cmd.ExecuteNonQuery();
                con.Close();

                result = "done";
                return result;

            }
            catch (Exception ex)
            {
                result = ex.ToString();
                return result;
            }
        }
    }
}