﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TruckManagementSystem.BL
{
    public class ShopsignupBL
    {
        public string Name;
        private string email;
        private string password;
        private int ReturnRate;
        public ShopsignupBL(string email, string password, string Name, int ReturnRate)
        {
            this.email = email;
            this.password = password;
            this.Name = Name; 
            this.ReturnRate = ReturnRate;
        }

        public ShopBoughtdataBL ShopBoughtdataBL
        {
            get => default;
            set
            {
            }
        }

        public ShopReturnTruck ShopReturnTruck
        {
            get => default;
            set
            {
            }
        }

        public static string ShopSignup(ShopsignupBL s,string sc)
        {
            string ans;
            try
            {
                ans="Successfull";
                SqlConnection conn = new SqlConnection(sc);
                conn.Open();
                Console.WriteLine(s.email);
                SqlCommand cm = new SqlCommand("insert into Shop(Email, Pass, ShopName, [Return Rate]) values('" + s.email + "', '" + s.password + "', '" + s.Name + "', '" + s.ReturnRate + "')", conn);
                cm.ExecuteNonQuery();
                conn.Close();
            }
            catch(Exception exp)
            {
                ans=exp.Message;
                return ans;
            }
            return ans;
        }

     
    }
}