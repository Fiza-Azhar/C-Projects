﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TruckManagementSystem.BL;
using TruckManagementSystem.DL;


namespace TruckManagementSystem.BL
{
    public class CustomerBL
    {
        private string FirstName;
        private string LastName;
        private int Gender;
        private string Email;
        private string Password;
        private int Contact;
        private string Role;

        public CustomerBL( string password, string role, string firstname, string lastname, int contact, string email, int gender)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.Gender = gender;
            this.Password = password;
            this.Email = email;
            this.Contact = contact;
            this.Role = role;
        }

        public CustomerBoughtBL CustomerBoughtBL
        {
            get => default;
            set
            {
            }
        }

        public CustomerReturnBL CustomerReturnBL
        {
            get => default;
            set
            {
            }
        }

        public static string AddCustomer(CustomerBL c, string con)
        {
            string ans = "done";
            try
            {
                SqlConnection conn = new SqlConnection(con);
                conn.Open();


                /*int pId = CustomerDL.GetPersonIdForSignup(con, c.FirstName, c.Email);
                bool customerExists = CustomerDL.checkCustomerExistsById(con, pId);
                if (customerExists)
                {
                    ans = "A customer with the same Id and Name already exists.";
                    return ans;
                }*/

                SqlCommand cmd = new SqlCommand("INSERT INTO Person(Pass, Role, FirstName, LastName, Contact, Email, Gender) values (@Pass, @Role, @FirstName, @LastName, @Contact, @Email, @Gender); SELECT SCOPE_IDENTITY()", conn);// SCOPE_IDENTITY() statement returns the auto-generated ID of the Person
                cmd.Parameters.AddWithValue("@Pass", c.Password ?? (object)DBNull.Value);  //using null-coalescing operator (??) to check for null values and replace them with DBNull.Value
                cmd.Parameters.AddWithValue("@Role", c.Role ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@FirstName", c.FirstName ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@LastName", c.LastName ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Contact", c.Contact == 0 ? (object)DBNull.Value : c.Contact);
                cmd.Parameters.AddWithValue("@Email", c.Email ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Gender", c.Gender == 0 ? (object)DBNull.Value : c.Gender);
                int personId = Convert.ToInt32(cmd.ExecuteScalar());
                cmd = new SqlCommand("INSERT INTO Customer(Id, Name) values (@Id, @Name)", conn);
                cmd.Parameters.AddWithValue("@Id", personId);
                cmd.Parameters.AddWithValue("@Name", c.FirstName + " " + c.LastName);
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                ans = e.Message;
                return ans;
            }
            return ans;
        }


        public static string CustomerSignup(CustomerBL s, string sc)
        {
            string ans;
            try
            {
                ans = "done";
                SqlConnection conn = new SqlConnection(sc);
                conn.Open();
                SqlCommand cm = new SqlCommand("Insert into Person(Pass, Role, FirstName, LastName, Contact, Email, Gender) values('" + s.Password + "', '" + s.Role + "', '" + s.FirstName + "', '" + s.LastName + "','" + s.Contact + "','" + s.Email + "','" + s.Gender + "')", conn);
                cm.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception exp)
            {
                ans = exp.Message;
                return ans;
            }
            return ans;
        }

    }
}





