﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace TruckManagementSystem.BL
{
    public class ShopBoughtdataBL
    {
        private int CId, SID,TId, Quantity, Price;
        private DateTime Date;
        public ShopBoughtdataBL(int CId, int TId, int SID,int price, int quantity, DateTime date)
        {
            this.CId = CId;
            this.SID = SID;
            this.TId = TId;
            this.Price = price;
            this.Quantity = quantity;
            this.Date = date;
        }
        public static string Adddata(ShopBoughtdataBL t, string con)
        {
            string ans ;
            try
            {
                ans = "done";
                SqlConnection conn2 = new SqlConnection(con);
                conn2.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO ShopBoughtData(CId,SID, TId, Quantity, Price, Date) values (@CId,@SID, @TId, @Quantity, @Price, @Date)", conn2);
                cmd.Parameters.AddWithValue("@CId", t.CId);
                cmd.Parameters.AddWithValue("@TId", t.TId);
                cmd.Parameters.AddWithValue("@SID", t.SID);
                cmd.Parameters.AddWithValue("@Quantity", t.Quantity);
                cmd.Parameters.AddWithValue("@Price", t.Price);
                cmd.Parameters.AddWithValue("@Date", t.Date);
                cmd.ExecuteNonQuery();
                SqlConnection con2 = new SqlConnection(con);
                con2.Open();
                SqlCommand cmd2 = new SqlCommand("INSERT INTO Shopsolddata(SId, TId, Quantity, Price, Date) values (@SId, @TId, @Quantity, @Price, @Date)", con2);
                cmd2.Parameters.AddWithValue("@SId", t.SID);
                cmd2.Parameters.AddWithValue("@TId", t.TId);
                cmd2.Parameters.AddWithValue("@Quantity", t.Quantity);
                cmd2.Parameters.AddWithValue("@Price", t.Price);
                cmd2.Parameters.AddWithValue("@Date", t.Date);
                cmd2.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                ans = e.Message;
                return ans;
            }
            return ans;
        }
    }
}